# Multiply Array
To complete this assessment, you need to multiply all values from the given array list.


```
example input:
[13,1,10];

expected output:
130
```