There is a list of 26 character heights aligned by index to their letters. For example, 'a' is at index 0 and 'z' is at index 25. There will also be a string. Using the letter heights given,

Example
 #####
    h = [
        1, 5, 2, 7, 1, 3, 1, 100,
        2, 33, 5, 20, 119, 5, 5, 5,
        20, 1, 17, 5, 12, 5, 13, 88,
        15, 77]
    word = 'aba'
 ####

The heights are a = 1, b = 5, a = 1 and . The tallest letter is 5 high and there are  letters. the formula is 5 * 3 = 15