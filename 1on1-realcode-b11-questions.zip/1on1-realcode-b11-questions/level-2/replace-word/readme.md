# Replace word

Given two parameters, first parameter is a student data containing name and GPA and the second parameter is the sentence

```
Replace {name} with student name and {GPA} with studeng GPA
```

## example

```js
first parameter : {
  name: 'Andika',
  GPA: 3.7
}

second parameter : "My name is {name} and my GPA is {GPA} of 4.0"

result = "My name is Andika and my GPA is 3.7 of 4.0"
```
